# Rocketshoes 
<h1 align="center" >  
  <img src="/readme-assets/screenshot.png" width="600"/>
</h1>

Projeto usando ReactJS e json-server.

Para iniciar o "banco de dados" do projeto instale o json-server.
https://github.com/typicode/json-server

## Inciar o projeto

Execute esse comando para instalatar todas as dependências.
`yarn install`

Depois, inicie o server: `json-server server.json -p 3333`

Agora inicie o aplicativo react: `yarn start`

